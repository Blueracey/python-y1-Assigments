let Maxwell = 7
let Tenley = 6
let Mona = 4
let vote = false 

function MaxwellV() { //vote function  Maxwell 
   
  Maxwell += 1 
  button.replaceWith("Maxwell: ",Maxwell )
  button.replaceWith("Tenley:  ",Tenley )
  button.replaceWith("Mona: ",Mona )
  console.log("Maxwell") }

    

function TenleyV() { //vote function Tenley
        Tenley += 1 
        button.replaceWith("Maxwell: ",Maxwell )
        button.replaceWith("Tenley:  ",Tenley )
        button.replaceWith("Mona: ",Mona )
        console.log("Tenley") }



function MonaV() { //vote function mona 
           Mona += 1 
           button.replaceWith("Maxwell: ",Maxwell )
           button.replaceWith("Tenley:  ",Tenley )
           button.replaceWith("Mona: ",Mona )
           
            console.log("MonaV") }









